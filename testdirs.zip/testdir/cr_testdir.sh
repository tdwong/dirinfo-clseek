#
mkdir -p dira/diraa/diraaa
mkdir -p dirb/dirbb/dirbbb
mkdir -p dirc/dircc
mkdir -p dird
#
echo "filea"	> dira/filea
echo "filea0"	> dira/filea0
echo "fileaa"	> dira/diraa/fileaa
echo "fileaa1"	> dira/diraa/fileaa1
echo "fileaa2"	> dira/diraa/fileaa2
echo "filebbb0"	> dirb/dirbb/dirbbb/filebbb0
echo "fileb"	> dirb/fileb
echo "fileb0"	> dirb/fileb0
echo "fileb1"	> dirb/fileb1
echo "filecc"	> dirc/dircc/filecc

