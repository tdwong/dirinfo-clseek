tree -D --timefmt '%Y:%m:%d %H:%M:%S' --sort=ctime
