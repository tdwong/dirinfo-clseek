#
mkdir -p dira/diraa/diraaa/dira4
mkdir -p dirb/dirbb/dirbbb
mkdir -p dirc/dircc
mkdir -p dird
#
echo "filea"	> dira/filea
echo "filea0"	> dira/filea0
echo "fileaa"	> dira/diraa/fileaa
echo "fileaa1"	> dira/diraa/fileaa1
echo "fileaa2"	> dira/diraa/fileaa2
echo "filea4"	> dira/diraa/diraaa/dira4/filea4
echo "filebbb0"	> dirb/dirbb/dirbbb/filebbb0
echo "fileb"	> dirb/fileb
echo "fileb0"	> dirb/fileb0
echo "fileb1"	> dirb/fileb1
echo "filecc"	> dirc/dircc/filecc
#
ln -s dira slink-dira
cd dirb ; ln -s dirbb slink-dirbb ; ln -s fileb1 slink-fileb1 ; cd ->/dev/null
cd dirc/dircc; ln -s filecc slink-filecc ; cd ->/dev/null

